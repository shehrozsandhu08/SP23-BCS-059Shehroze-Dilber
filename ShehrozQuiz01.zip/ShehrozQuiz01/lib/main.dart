import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Student Registration Form',
      home: const RegistrationForm(),
      debugShowCheckedModeBanner: false,
    );
  }
}

class RegistrationForm extends StatefulWidget {
  const RegistrationForm({super.key});

  @override
  State<RegistrationForm> createState() => _RegistrationFormState();
}

class _RegistrationFormState extends State<RegistrationForm> {
  // TextField controllers
  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _regController = TextEditingController();

  // Radio Button - Gender
  String? _selectedGender;

  // Checkbox - Hobbies
  bool _reading = false;
  bool _sports = false;

  // Option List (DropdownButton with 2-3 options)
  String? _selectedOption;
  final List<String> _options = ['Option 1', 'Option 2', 'Option 3'];

  // Selection List (ListTile with checkboxes for 2-3 selectable items)
  List<bool> _selectionList = [false, false, false];
  final List<String> _selectionItems = ['Item 1', 'Item 2', 'Item 3'];

  // Dropdown List - Department
  String? _selectedDepartment;
  final List<String> _departments = ['CS', 'IT', 'SE', 'AI'];

  @override
  void dispose() {
    _nameController.dispose();
    _regController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Student Registration Form'),
      ),
      body: SingleChildScrollView(
        child: Center(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              const SizedBox(height: 20),

              // 1. Text - Display a heading
              const Text(
                'Student Registration Form',
                style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
              ),

              const SizedBox(height: 20),

              // 2. TextField - Enter Student Name
              SizedBox(
                width: 300,
                child: TextField(
                  controller: _nameController,
                  decoration: const InputDecoration(
                    labelText: 'Student Name',
                    border: OutlineInputBorder(),
                  ),
                ),
              ),

              const SizedBox(height: 15),

              // 3. TextField - Enter Registration Number
              SizedBox(
                width: 300,
                child: TextField(
                  controller: _regController,
                  decoration: const InputDecoration(
                    labelText: 'Registration Number',
                    border: OutlineInputBorder(),
                  ),
                ),
              ),

              const SizedBox(height: 15),

              // 4. Radio Button - Select Gender (Male/Female)
              const Text('Select Gender:'),
              Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Radio<String>(
                    value: 'Male',
                    groupValue: _selectedGender,
                    onChanged: (value) {
                      setState(() {
                        _selectedGender = value;
                      });
                    },
                  ),
                  const Text('Male'),
                  Radio<String>(
                    value: 'Female',
                    groupValue: _selectedGender,
                    onChanged: (value) {
                      setState(() {
                        _selectedGender = value;
                      });
                    },
                  ),
                  const Text('Female'),
                ],
              ),

              const SizedBox(height: 15),

              // 5. Checkbox - Select Hobbies (Reading/Sports)
              const Text('Select Hobbies:'),
              Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Checkbox(
                    value: _reading,
                    onChanged: (value) {
                      setState(() {
                        _reading = value!;
                      });
                    },
                  ),
                  const Text('Reading'),
                  Checkbox(
                    value: _sports,
                    onChanged: (value) {
                      setState(() {
                        _sports = value!;
                      });
                    },
                  ),
                  const Text('Sports'),
                ],
              ),

              const SizedBox(height: 15),

              // 6. Option List - Display 2-3 options (using DropdownButton)
              const Text('Option List:'),
              DropdownButton<String>(
                hint: const Text('Select an Option'),
                value: _selectedOption,
                items: _options.map((String option) {
                  return DropdownMenuItem<String>(
                    value: option,
                    child: Text(option),
                  );
                }).toList(),
                onChanged: (value) {
                  setState(() {
                    _selectedOption = value;
                  });
                },
              ),

              const SizedBox(height: 15),

              // 7. Selection List - Display 2-3 selectable items
              const Text('Selection List:'),
              SizedBox(
                width: 300,
                child: Column(
                  children: List.generate(_selectionItems.length, (index) {
                    return CheckboxListTile(
                      title: Text(_selectionItems[index]),
                      value: _selectionList[index],
                      onChanged: (value) {
                        setState(() {
                          _selectionList[index] = value!;
                        });
                      },
                    );
                  }),
                ),
              ),

              const SizedBox(height: 15),

              // 8. Dropdown List - Select Department (CS/IT/SE/AI)
              const Text('Select Department:'),
              DropdownButton<String>(
                hint: const Text('Select Department'),
                value: _selectedDepartment,
                items: _departments.map((String dept) {
                  return DropdownMenuItem<String>(
                    value: dept,
                    child: Text(dept),
                  );
                }).toList(),
                onChanged: (value) {
                  setState(() {
                    _selectedDepartment = value;
                  });
                },
              ),

              const SizedBox(height: 15),

              // 9. Button - Add a simple button
              ElevatedButton(
                onPressed: () {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('Button Pressed!')),
                  );
                },
                child: const Text('Simple Button'),
              ),

              const SizedBox(height: 15),

              // 10. Submit Button - Add a Submit button
              ElevatedButton(
                onPressed: () {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('Form Submitted!')),
                  );
                },
                child: const Text('Submit'),
              ),

              const SizedBox(height: 30),
            ],
          ),
        ),
      ),
    );
  }
}
